#ifndef _NET_PPP_DEFS_H
#define _NET_PPP_DEFS_H

#define __need_time_t
#include <time.h>

#include <asm/types.h>
#include <linux/ppp_defs.h>

#endif

