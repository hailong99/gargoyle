The file oic_svr_db.cbor in generated from the oic_svr_db.json with the
resource/csdk/security/tool/json2cbor.c tool.
