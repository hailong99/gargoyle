@ifndef HAVE_UNISTD_H 
 @define HAVE_UNISTD_H
@endif
@ifndef HAVE_PWD_H 
 @define HAVE_PWD_H
@endif
@ifndef HAVE_SYS_TYPES_H 
 @define HAVE_SYS_TYPES_H
@endif
@ifndef HAVE_LONG_LONG 
 @define HAVE_LONG_LONG
@endif
@ifndef ODBCINT64
 @define ODBCINT64 long
@endif
@ifndef UODBCINT64
 @define UODBCINT64 unsigned long
@endif
@ifndef SIZEOF_LONG_INT
 @define SIZEOF_LONG_INT __SIZEOF_LONG__
@endif
 