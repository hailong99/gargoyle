#!/bin/sh
# Copyright (C) 2015 OpenWrt.org

SUMO_HOME=/usr/share/sumo sumo-bin $@

exit $?
